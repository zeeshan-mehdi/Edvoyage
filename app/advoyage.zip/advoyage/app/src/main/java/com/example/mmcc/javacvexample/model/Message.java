package com.example.mmcc.javacvexample.model;

public class Message {
    public String text;
    public String sendBy;

    public Message(String text, String sendBy) {
        this.text = text;
        this.sendBy = sendBy;
    }

    public Message() {
    }
}

